@extends('layouts.main')

@section('content')
  <h1>halo</h1>



@endsection