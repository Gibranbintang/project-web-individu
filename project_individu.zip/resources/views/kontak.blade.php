@extends('layouts.main')

@section('content')
  <h1>ini page kontak</h1>



@endsection