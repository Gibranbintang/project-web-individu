

<?php $__env->startSection('content'); ?>
<h1>profile</h1>

<h2><?php echo e($nama); ?></h2>
<h3><?php echo e($nohp); ?></h3>
<img src="<?php echo e(asset('img/' . $foto)); ?>" width="100px" />

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ProjectIndividu_web\project_individu\resources\views/profile.blade.php ENDPATH**/ ?>