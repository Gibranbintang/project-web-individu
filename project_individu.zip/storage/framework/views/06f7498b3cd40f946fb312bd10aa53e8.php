

<?php $__env->startSection('content'); ?>
  




<body>
    

    <div class="container mt-4">
        <h2>Data Mahasiswa</h2>
        
        <a href="tambahmahasiswa">
            <button type="button" class="btn btn-success mb-3">Tambah Data</button>
        </a>

        <table class="table table-bordered">
            <thead class="thead-dark">
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">Nama</th>
                    <th scope="col">NIM</th>
                    <th scope="col">Prodi</th>
                    <th scope="col">Email</th>
                    <th scope="col">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $mahasiswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $mhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($index + 1); ?></th>
                    <td><?php echo e($mhs->name); ?></td>
                    <td><?php echo e($mhs->nim); ?></td>
                    <td><?php echo e($mhs->prodi); ?></td>
                    <td><?php echo e($mhs->email); ?></td>
                    <td>
                        <a href="tampildata/<?php echo e($mhs ->id); ?>"class="btn btn-primary">Edit</a>
                        <a href="deletedata/<?php echo e($mhs ->id); ?>"class="btn btn-danger">Hapus</a>
                        
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ProjectIndividu_web\project_individu\resources\views/mahasiswa.blade.php ENDPATH**/ ?>