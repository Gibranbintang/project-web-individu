

<?php $__env->startSection('content'); ?>
  <h1>ini page kontak</h1>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ProjectIndividu_web\project_individu\resources\views/kontak.blade.php ENDPATH**/ ?>