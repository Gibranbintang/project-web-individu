    
<?php $__env->startSection('content'); ?>

<article>
<h1>BERITA</h1>

            <?php $__currentLoopData = $beritas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="/berita/<?php echo e($berita['slug']); ?>"><h2><?php echo e($berita["judul"]); ?></h2></a>
                <h3><?php echo e($berita["penulis"]); ?></h3>
                <p><?php echo e($berita["isi"]); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</article> 


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project kelompok 5\project_individu\resources\views/berita.blade.php ENDPATH**/ ?>